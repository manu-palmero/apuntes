public class Cuadrilatero extends Poligono {
    static final int LADOS = 4;

    public Cuadrilatero(Lado[] l) {
        // Constructor
        super(Cuadrilatero.LADOS, l);
    }
}
