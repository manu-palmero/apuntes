public class Gusto {
    Restaurante restaurante;
    Plato plato;

    public Gusto(Restaurante restaurante, Plato plato) {
        this.restaurante = restaurante;
        this.plato = plato;
    }
}
