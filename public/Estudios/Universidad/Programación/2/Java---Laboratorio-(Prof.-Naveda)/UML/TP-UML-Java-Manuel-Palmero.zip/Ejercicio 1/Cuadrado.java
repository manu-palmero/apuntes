public class Cuadrado extends Rectangulo {
    public Cuadrado(Lado[] l) {
        super(l);
    }
}
