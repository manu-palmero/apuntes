import java.util.ArrayList;

public class Cocecha_Fina extends Cereal {
    // Constructor

    public Cocecha_Fina(String nombre, ArrayList<Mineral> mineralesRequeridos) {
        super(nombre, mineralesRequeridos);

    }

}
