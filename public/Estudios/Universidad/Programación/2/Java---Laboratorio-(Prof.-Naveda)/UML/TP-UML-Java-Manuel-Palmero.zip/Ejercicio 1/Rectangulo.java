public class Rectangulo extends Cuadrilatero {
    // Constructor
    public Rectangulo(Lado[] l) {
        super(l);
    }

}