public class Mineral {
    private String nombre;

    public Mineral(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }

}
