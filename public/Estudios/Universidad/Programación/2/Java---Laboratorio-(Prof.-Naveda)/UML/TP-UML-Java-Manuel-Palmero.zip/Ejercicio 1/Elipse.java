public class Elipse extends Figura {
    public Elipse() {
        // Constructor
        super();
    }
}
