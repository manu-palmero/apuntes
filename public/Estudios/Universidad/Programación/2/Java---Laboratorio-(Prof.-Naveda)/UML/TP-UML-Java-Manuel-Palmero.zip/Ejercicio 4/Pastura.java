import java.util.ArrayList;

public class Pastura extends Cereal {
    // Constructor
    public Pastura(String nombre, ArrayList<Mineral> mineralesRequeridos) {
        super(nombre, mineralesRequeridos);
    }
}
