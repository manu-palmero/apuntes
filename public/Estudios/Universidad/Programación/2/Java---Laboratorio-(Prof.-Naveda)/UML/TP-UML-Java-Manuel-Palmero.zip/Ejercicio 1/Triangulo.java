public class Triangulo extends Poligono {
    static final int LADOS = 3;

    public Triangulo(Lado[] l) {
        // Constructor
        super(Triangulo.LADOS, l);
    }

}