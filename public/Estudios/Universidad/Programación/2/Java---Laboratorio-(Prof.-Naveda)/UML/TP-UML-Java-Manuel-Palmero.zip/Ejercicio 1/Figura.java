public class Figura {
    public Figura() {
        // Constructor
    }
}
