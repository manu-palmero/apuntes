public class Circulo extends Elipse {
    public Circulo() {
        // Constructor
        super();
    }

}
