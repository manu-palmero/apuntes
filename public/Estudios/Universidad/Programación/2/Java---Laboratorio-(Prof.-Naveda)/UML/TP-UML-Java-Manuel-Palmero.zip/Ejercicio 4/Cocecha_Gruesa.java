import java.util.ArrayList;

public class Cocecha_Gruesa extends Cereal {
    // Constructor
    public Cocecha_Gruesa(String nombre, ArrayList<Mineral> mineralesRequeridos) {
        super(nombre, mineralesRequeridos);
    }

}
