public class Plato {
    String nombre;

    public Plato(String nombre) {
        this.nombre = nombre;
    }
}
