CREATE TABLE PRODUCTO (
    CodigoProducto INT PRIMARY KEY,
    Descripcion VARCHAR(100) NOT NULL,
    Precio DECIMAL(10,2) NOT NULL,
    NumExistencias INT NOT NULL
);

CREATE TABLE CLIENTE (
    CodigoCliente INT PRIMARY KEY,
    Nombre VARCHAR(50) NOT NULL,
    Apellidos VARCHAR(80) NOT NULL,
    Direccion VARCHAR(150),
    Telefono VARCHAR(20)
);

CREATE TABLE PROVEEDOR (
    CodigoProveedor INT PRIMARY KEY,
    Nombre VARCHAR(50) NOT NULL,
    Apellidos VARCHAR(80) NOT NULL,
    Direccion VARCHAR(150),
    Provincia VARCHAR(50),
    Telefono VARCHAR(20)
);

CREATE TABLE COMPRA (
    CodigoCompra INT PRIMARY KEY AUTO_INCREMENT,
    FechaCompra DATE NOT NULL,
    CodigoCliente INT NOT NULL,
    CodigoProducto INT NOT NULL,
    FOREIGN KEY (CodigoCliente) REFERENCES CLIENTE(CodigoCliente),
    FOREIGN KEY (CodigoProducto) REFERENCES PRODUCTO(CodigoProducto)
);


CREATE TABLE SUMINISTRO (
    CodigoProveedor INT NOT NULL,
    CodigoProducto INT NOT NULL,
    PRIMARY KEY (CodigoProveedor, CodigoProducto),
    FOREIGN KEY (CodigoProveedor) REFERENCES PROVEEDOR(CodigoProveedor),
    FOREIGN KEY (CodigoProducto) REFERENCES PRODUCTO(CodigoProducto)
);
