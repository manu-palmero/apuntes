Use ejercicio1;

-- Insert de datos Ejercicio 1
INSERT INTO Cliente (cuit, nombre, apellidos, direccion, fecha_nacimiento) VALUES
('20123456789', 'Lucía', 'Gómez', 'Av. San Martín 123', '1990-05-12'),
('20234567890', 'Martín', 'Pérez', 'Calle Belgrano 456', '1985-11-03'),
('20345678901', 'Sofía', 'López', 'Ruta 40 Km 12', '1992-07-25');

INSERT INTO Proveedor (cuit, nombre, direccion) VALUES
('30111222333', 'Distribuidora Mendoza', 'Av. Las Heras 789'),
('30222333444', 'Proveeduría Andina', 'Calle Mitre 321');

INSERT INTO Producto (codigo, nombre, precio_unitario, cuit_proveedor) VALUES
(101, 'Yerba Mate', 1200.50, '30111222333'),
(102, 'Aceite de Oliva', 2500.00, '30222333444'),
(103, 'Vino Malbec', 3500.75, '30111222333');

INSERT INTO Compra (cuit_cliente, codigo_producto, fecha_compra, cantidad) VALUES
('20123456789', 101, '2025-08-20', 2),
('20234567890', 102, '2025-08-21', 1),
('20345678901', 103, '2025-08-22', 3),
('20123456789', 103, '2025-08-23', 1);

