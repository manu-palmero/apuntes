INSERT INTO PRODUCTO (CodigoProducto, Descripcion, Precio, NumExistencias) VALUES
(1, 'Notebook Lenovo IdeaPad 15"', 450000.00, 10),
(2, 'Mouse Logitech M170', 7500.00, 50),
(3, 'Teclado Mecánico Redragon', 25000.00, 20),
(4, 'Monitor Samsung 24"', 120000.00, 15),
(5, 'Disco SSD Kingston 480GB', 35000.00, 30);

INSERT INTO CLIENTE (CodigoCliente, Nombre, Apellidos, Direccion, Telefono) VALUES
(1, 'Juan', 'Pérez', 'Av. San Martín 123, Mendoza', '2614556677'),
(2, 'María', 'Gómez', 'Calle Belgrano 456, Córdoba', '3514432211'),
(3, 'Carlos', 'López', 'Ruta 40 km 12, San Luis', '2664223344'),
(4, 'Ana', 'Fernández', 'Mitre 789, Buenos Aires', '1144221133');

INSERT INTO PROVEEDOR (CodigoProveedor, Nombre, Apellidos, Direccion, Provincia, Telefono) VALUES
(1, 'Pedro', 'Luna', 'Calle Libertad 101, Rosario', 'Santa Fe', '3414228899'),
(2, 'Uriel', 'Ramírez', 'Av. Colón 250, Córdoba', 'Córdoba', '3514889900'),
(3, 'Fabrizio', 'Castillo', 'San Juan 500, Mendoza', 'Mendoza', '2614771122');

INSERT INTO COMPRA (FechaCompra, CodigoCliente, CodigoProducto) VALUES
('2025-08-01', 1, 1),
('2025-08-02', 1, 2),
('2025-08-03', 2, 3),
('2025-08-05', 3, 5),
('2025-08-07', 4, 4),
('2025-08-10', 2, 2);

INSERT INTO SUMINISTRO (CodigoProveedor, CodigoProducto) VALUES
(1, 1), 
(1, 2), 
(2, 3), 
(2, 5), 
(3, 4), 
(3, 1); 
