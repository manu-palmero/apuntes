use ejercicio_4;

-- CREACION DE TABLAS MAESTRAS

create table cliente(
	id INT PRIMARY KEY ,
    nif INT(15) NOT NULL,
    nombre VARCHAR(40) NOT NULL,
    direccion VARCHAR(50) NOT NULL,
    ciudad VARCHAR(40) NOT NULL,
    numero_telefono VARCHAR(30) NOT NULL 
    
);

create table auto(
	id INT PRIMARY KEY,
    matricula VARCHAR(40),
    marca VARCHAR(15),
    modelo VARCHAR(20),
    color VARCHAR(20),
    precio DECIMAL(20),
    id_cliente INT,
    FOREIGN KEY (id_cliente) REFERENCES cliente(id)
);

create table revision(
	id INT PRIMARY KEY,
    cambio_filtro BOOLEAN,
    cambio_aceite BOOLEAN,
    cambio_frenos BOOLEAN,
    id_auto INT,
    foreign key (id_auto) references auto(id)
);


-- INSERT DATOS
INSERT INTO cliente (id, nif, nombre, direccion, ciudad, numero_telefono) VALUES
(1, 20345678901, 'Lucía Martínez', 'Av. Las Heras 123', 'Mendoza', '2614556677'),
(2, 20987654321, 'Julián Torres', 'Calle San Juan 456', 'Córdoba', '3514432211'),
(3, 20123456789, 'Sofía Gómez', 'Ruta 40 km 12', 'San Luis', '2664223344'),
(4, 20876543210, 'Martín López', 'Mitre 789', 'Buenos Aires', '1144221133');


INSERT INTO auto (id, matricula, marca, modelo, color, precio, id_cliente) VALUES
(101, 'AB123CD', 'Toyota', 'Corolla', 'Blanco', 3500000.00, 1),
(102, 'EF456GH', 'Ford', 'Focus', 'Negro', 4200000.00, 2),
(103, 'IJ789KL', 'Renault', 'Sandero', 'Rojo', 3100000.00, 3),
(104, 'MN012OP', 'Volkswagen', 'Gol Trend', 'Gris', 3300000.00, 4),
(105, 'QR345ST', 'Chevrolet', 'Onix', 'Azul', 3600000.00, 2);


INSERT INTO revision (id, cambio_filtro, cambio_aceite, cambio_frenos, id_auto) VALUES
(1, TRUE, TRUE, FALSE, 101),
(2, FALSE, TRUE, TRUE, 102),
(3, TRUE, FALSE, TRUE, 103),
(4, FALSE, FALSE, FALSE, 104),
(5, TRUE, TRUE, TRUE, 105);
