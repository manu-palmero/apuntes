use ejercicio2;


INSERT INTO Camionero (cuit, nombre, telefono, direccion, salario, poblacion) VALUES
('20345678901', 'Carlos Gómez', '2614123456', 'Av. Las Heras 123', 250000.00, 'Mendoza'),
('20456789012', 'María López', '2614234567', 'Calle San Juan 456', 270000.00, 'San Rafael'),
('20567890123', 'Juan Pérez', '2614345678', 'Ruta 40 Km 12', 260000.00, 'Godoy Cruz');

INSERT INTO Provincia (codigo_provincia, nombre) VALUES
(1, 'Mendoza'),
(2, 'San Juan'),
(3, 'Córdoba');

INSERT INTO Camion (matricula, modelo, tipo, potencia) VALUES
('ABC123', 'Scania R450', 'Carga pesada', 450),
('DEF456', 'Mercedes Actros', 'Carga media', 400),
('GHI789', 'Volvo FH', 'Carga pesada', 500);

INSERT INTO Paquete (codigo_paquete, descripcion, destinatario, direccion_destinatario, cuit_camionero, codigo_provincia) VALUES
(1001, 'Electrodomésticos', 'Lucía Fernández', 'Calle Mitre 789', '20345678901', 1),
(1002, 'Libros escolares', 'Martín Ruiz', 'Av. Libertador 321', '20456789012', 2),
(1003, 'Ropa deportiva', 'Sofía Torres', 'Ruta 9 Km 45', '20567890123', 3),
(1004, 'Herramientas', 'Diego Castro', 'Calle Sarmiento 654', '20345678901', 1);

INSERT INTO Conduccion (cuit_camionero, matricula_camion, fecha) VALUES
('20345678901', 'ABC123', '2025-08-20'),
('20456789012', 'DEF456', '2025-08-21'),
('20567890123', 'GHI789', '2025-08-22'),
('20345678901', 'GHI789', '2025-08-23');
