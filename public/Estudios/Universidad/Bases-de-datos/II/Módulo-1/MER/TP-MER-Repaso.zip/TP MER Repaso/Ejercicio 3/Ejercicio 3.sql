CREATE DATABASE IF NOT EXISTS Instituto;

CREATE table IF NOT EXISTS Instituto.Alumnos (
    n_alumno INT PRIMARY KEY NOT NULL,
    nombre VARCHAR(50) NOT NULL,
    apellidos VARCHAR(50) NOT NULL,
    n_matricula INT NOT NULL,
    fecha_nacimiento DATE NOT NULL
);

CREATE table IF NOT EXISTS Instituto.Profesores (
    dni INT PRIMARY KEY NOT NULL,
    nombre VARCHAR(50) NOT NULL,
    direccion VARCHAR(100) NOT NULL,
    telefono VARCHAR(20)
);

CREATE table IF NOT EXISTS Instituto.Modulos (
    codigo_modulo INT PRIMARY KEY NOT NULL,
    nombre VARCHAR(100) NOT NULL,
    profesor_dni INT,
    FOREIGN KEY (profesor_dni) REFERENCES Instituto.Profesores(dni)
);

CREATE table IF NOT EXISTS Instituto.Matriculas (
    codigo_modulo INT NOT NULL,
    n_alumno INT NOT NULL,
    FOREIGN KEY (n_alumno) REFERENCES Instituto.Alumnos(n_alumno),
    FOREIGN KEY (codigo_modulo) REFERENCES Instituto.Modulos(codigo_modulo)
);