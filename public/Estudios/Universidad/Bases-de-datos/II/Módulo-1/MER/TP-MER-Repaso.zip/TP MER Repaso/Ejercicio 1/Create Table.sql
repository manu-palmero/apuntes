-- Tabla Cliente EJERCICIO 1
CREATE TABLE Cliente (
    cuit CHAR(11) PRIMARY KEY,
    nombre VARCHAR(50),
    apellidos VARCHAR(50),
    direccion VARCHAR(100),
    fecha_nacimiento DATE
);

-- Tabla Proveedor
CREATE TABLE Proveedor (
    cuit CHAR(11) PRIMARY KEY,
    nombre VARCHAR(50),
    direccion VARCHAR(100)
);

-- Tabla Producto
CREATE TABLE Producto (
    codigo INT PRIMARY KEY,
    nombre VARCHAR(50),
    precio_unitario DECIMAL(10,2),
    cuit_proveedor CHAR(11),
    FOREIGN KEY (cuit_proveedor) REFERENCES Proveedor(cuit)
);

-- Tabla Compra
CREATE TABLE Compra (
    cuit_cliente CHAR(11),
    codigo_producto INT,
    fecha_compra DATE,
    cantidad INT,
    PRIMARY KEY (cuit_cliente, codigo_producto, fecha_compra),
    FOREIGN KEY (cuit_cliente) REFERENCES Cliente(cuit),
    FOREIGN KEY (codigo_producto) REFERENCES Producto(codigo)
);
