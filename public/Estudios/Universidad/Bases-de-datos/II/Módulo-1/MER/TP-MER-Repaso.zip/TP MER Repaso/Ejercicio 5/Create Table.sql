CREATE TABLE PACIENTE (
    CodigoPaciente INT PRIMARY KEY,
    Nombre VARCHAR(50) NOT NULL,
    Apellidos VARCHAR(80) NOT NULL,
    Direccion VARCHAR(150),
    Poblacion VARCHAR(50),
    Provincia VARCHAR(50),
    CodigoPostal VARCHAR(10),
    Telefono VARCHAR(20),
    FechaNacimiento DATE
);

CREATE TABLE MEDICO (
    CodigoMedico INT PRIMARY KEY,
    Nombre VARCHAR(50) NOT NULL,
    Apellidos VARCHAR(80) NOT NULL,
    Telefono VARCHAR(20),
    Especialidad VARCHAR(50) NOT NULL
);

CREATE TABLE INGRESO (
    CodigoIngreso INT PRIMARY KEY AUTO_INCREMENT,
    FechaIngreso DATE NOT NULL,
    NumeroHabitacion INT NOT NULL,
    NumeroCama INT NOT NULL,
    CodigoPaciente INT NOT NULL,
    CodigoMedico INT NOT NULL,
    FOREIGN KEY (CodigoPaciente) REFERENCES PACIENTE(CodigoPaciente),
    FOREIGN KEY (CodigoMedico) REFERENCES MEDICO(CodigoMedico)
);
