INSERT INTO PACIENTE (CodigoPaciente, Nombre, Apellidos, Direccion, Poblacion, Provincia, CodigoPostal, Telefono, FechaNacimiento) VALUES
(1, 'Juan', 'Pérez', 'Av. Libertad 123', 'Mendoza', 'Mendoza', '5500', '2614556677', '1985-03-12'),
(2, 'María', 'Gómez', 'Calle Belgrano 456', 'Córdoba', 'Córdoba', '5000', '3514332211', '1990-07-25'),
(3, 'Carlos', 'López', 'San Juan 789', 'San Luis', 'San Luis', '5700', '2664223344', '1978-11-05'),
(4, 'Ana', 'Fernández', 'Mitre 321', 'Rosario', 'Santa Fe', '2000', '3414778899', '1995-09-15');

INSERT INTO MEDICO (CodigoMedico, Nombre, Apellidos, Telefono, Especialidad) VALUES
(1, 'Pedro', 'Martínez', '2614001122', 'Cardiología'),
(2, 'Lucía', 'Ramírez', '3514112233', 'Pediatría'),
(3, 'Sofía', 'Castillo', '3414556677', 'Neurología'),
(4, 'Miguel', 'Torres', '2664334455', 'Traumatología');

INSERT INTO INGRESO (FechaIngreso, NumeroHabitacion, NumeroCama, CodigoPaciente, CodigoMedico) VALUES
('2025-08-01', 101, 1, 1, 1), 
('2025-08-02', 102, 2, 2, 2),
('2025-08-03', 103, 1, 3, 3), 
('2025-08-05', 101, 2, 1, 4),
('2025-08-07', 104, 1, 4, 2); 
