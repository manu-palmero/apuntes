use ejercicio2;

-- Tabla Camionero
CREATE TABLE Camionero (
    cuit CHAR(11) PRIMARY KEY,
    nombre VARCHAR(50),
    telefono VARCHAR(20),
    direccion VARCHAR(100),
    salario DECIMAL(10,2),
    poblacion VARCHAR(50)
);

-- Tabla Provincia
CREATE TABLE Provincia (
    codigo_provincia INT PRIMARY KEY,
    nombre VARCHAR(50)
);

-- Tabla Camión
CREATE TABLE Camion (
    matricula VARCHAR(15) PRIMARY KEY,
    modelo VARCHAR(50),
    tipo VARCHAR(30),
    potencia INT
);

-- Tabla Paquete
CREATE TABLE Paquete (
    codigo_paquete INT PRIMARY KEY,
    descripcion VARCHAR(100),
    destinatario VARCHAR(50),
    direccion_destinatario VARCHAR(100),
    cuit_camionero CHAR(11),
    codigo_provincia INT,
    FOREIGN KEY (cuit_camionero) REFERENCES Camionero(cuit),
    FOREIGN KEY (codigo_provincia) REFERENCES Provincia(codigo_provincia)
);

-- Tabla Conducción (relación muchos a muchos entre Camionero y Camión)
CREATE TABLE Conduccion (
    cuit_camionero CHAR(11),
    matricula_camion VARCHAR(15),
    fecha DATE,
    PRIMARY KEY (cuit_camionero, matricula_camion, fecha),
    FOREIGN KEY (cuit_camionero) REFERENCES Camionero(cuit),
    FOREIGN KEY (matricula_camion) REFERENCES Camion(matricula)
);
